package com.example.homeofficeapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CadastroUsuariosActivity extends AppCompatActivity {

    EditText editTextEmail, editTextSenha, editTextNome;
    Button buttonCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_usuarios);

        editTextEmail = findViewById(R.id.editTextCadastroEmail);
        editTextSenha = findViewById(R.id.editTextCadastroSenha);
        editTextNome = findViewById(R.id.editTextCadastroNome);
        buttonCadastrar = findViewById(R.id.buttonCadastrar);
    }




    boolean validaCamposCadastro(){

        String nome, email, senha;
        nome = editTextNome.getText().toString();
        email = editTextEmail.getText().toString();
        senha = editTextSenha.getText().toString();

        if(nome.isEmpty() || nome.length() < 3){
            Toast.makeText(this, "Preencha o campo nome corretamente!", Toast.LENGTH_SHORT).show();
            editTextNome.requestFocus();
            return  false;
        }else if (email.isEmpty() || !email.contains("@") || email.length() < 6){
            Toast.makeText(this, "Preencha o campo e-mail corretamente!", Toast.LENGTH_SHORT).show();
            editTextEmail.requestFocus();
            return false;
        }else if (senha.isEmpty() || senha.length() < 6){
            Toast.makeText(this, "Preencha o campo senha corretamente!", Toast.LENGTH_SHORT).show();
            editTextSenha.requestFocus();
            return false;
        }else{
            return true;
        }
    }



    
    public void cadastraUsuario(View view){
        //se tudo estiver ok na validacao inicia o processo de cadasrto
        if(validaCamposCadastro()){
            final String email, senha, nome;
            //cria a variavel que se comunica com o firebase
            final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("usuario");

            email = editTextEmail.getText().toString();
            senha = editTextSenha.getText().toString();
            nome = editTextNome.getText().toString();
            //cria um instancia do firebase
            FirebaseAuth auth = FirebaseAuth.getInstance();
            //chama o metodo de criacao de usuario do firebase
            auth.createUserWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {

                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    //se tudo deu certo cria a variavel da classe usuario
                    ClasseUsuario usuario = new ClasseUsuario();
                    //passa o id gerado pelo firebase para a variavel usuario
                    usuario.setId(task.getResult().getUser().getUid());
                    //guarda os valores nos atributos da classe
                    usuario.setEmail(email);
                    usuario.setNome(nome);
                    usuario.setSenha(senha);
                    //salva dentro da tabela usuarios do firebase
                    reference.child(usuario.getId()).setValue(usuario);
                    //abre a activity de atividades
                    Intent atividades = new Intent(CadastroUsuariosActivity.this, AtividadesActivity.class);
                    startActivity(atividades);
                }else{
                    //se não deu certo uma mensagem é exibida
                    String mensagem = "Falha ao cadastrar!";
                    Toast.makeText(CadastroUsuariosActivity.this, mensagem, Toast.LENGTH_SHORT).show();
                }
                }
            });
        }
    }
}







