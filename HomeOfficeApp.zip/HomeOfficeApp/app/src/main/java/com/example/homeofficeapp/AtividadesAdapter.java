package com.example.homeofficeapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AtividadesAdapter extends RecyclerView.Adapter<AtividadesAdapter.MyViewHolder> {

    private List<Atividade> atividades;
    private Context context;

    public AtividadesAdapter(List<Atividade> atividades, Context context){
        this.atividades = atividades;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View item = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_atividades, parent, false);
        return new  MyViewHolder(item);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position){
        Atividade atividade = atividades.get(position);

        holder.id.setText("ID: " + atividade.getIdFuncionario());
        holder.email.setText("E-mail: " + atividade.getEmail());
        holder.horaInicio.setText("Hora de inicio: " + atividade.getHoraInicio());
        holder.horaFim.setText("Hora do fim: " + atividade.getHoraFim());
        holder.dataInicio.setText("Data de inicio: " + atividade.getDataInicio());
        holder.dataFim.setText("Data do fim: " + atividade.getDataFim());
        holder.atividade.setText("Atividade: " + atividade.getAtividade());
    }

    @Override
    public int getItemCount(){return atividades.size();}

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView atividade, dataInicio, dataFim, horaInicio, horaFim, email, id;

        public MyViewHolder(View itemView){
            super(itemView);

            atividade = itemView.findViewById(R.id.textViewAdapterAtividade);
            dataInicio = itemView.findViewById(R.id.textViewAdapterDataInicio);
            dataFim = itemView.findViewById(R.id.textViewAdapterDataFim);
            horaInicio = itemView.findViewById(R.id.textViewAdapterHoraInicio);
            horaFim = itemView.findViewById(R.id.textViewAdapterHoraFim);
            email = itemView.findViewById(R.id.textViewAdapterEmail);
            id = itemView.findViewById(R.id.textViewAdapterId);
        }
    }
}
