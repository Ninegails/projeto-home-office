package com.example.homeofficeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CadastroUsuariosActivityteste extends AppCompatActivity {

    EditText editTextNome, editTextEmail, editTextSenha;
    Button buttonCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_usuarios);

        editTextNome = findViewById(R.id.editTextCadastroNome);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextSenha = findViewById(R.id.editTextSenha);
        buttonCadastrar = findViewById(R.id.buttonCadastrar);
    }

     boolean validaCamposCadastro(){
        String nome, email, senha;
        nome = editTextNome.getText().toString();
        email = editTextEmail.getText().toString();
        senha = editTextSenha.getText().toString();

         if(nome.isEmpty() || nome.length() < 3){
             Toast.makeText(this, "Preencha o campo nome corretamente!", Toast.LENGTH_SHORT).show();
             editTextNome.requestFocus();
             return  false;
         }else if (email.isEmpty() || !email.contains("@") || email.length() < 6){
             Toast.makeText(this, "Preencha o campo e-mail corretamente!", Toast.LENGTH_SHORT).show();
             editTextEmail.requestFocus();
             return false;
         }else if (senha.isEmpty() || senha.length() < 6){
             Toast.makeText(this, "Preencha o campo senha corretamente!", Toast.LENGTH_SHORT).show();
             editTextSenha.requestFocus();
             return false;
         }else{
             return true;
         }
     }

     public void cadastraUsuario(View view){

        if(validaCamposCadastro()){

            final String email, senha, nome;
            final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("usuario");

            email = editTextEmail.getText().toString();
            senha = editTextSenha.getText().toString();
            nome = editTextNome.getText().toString();

            FirebaseAuth auth = FirebaseAuth.getInstance();

            auth.createUserWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        ClasseUsuario usuario = new ClasseUsuario();
                        usuario.setId(task.getResult().getUser().getUid());
                        usuario.setEmail(email);
                        usuario.setSenha(senha);
                        usuario.setNome(nome);

                        reference.child(usuario.getId()).setValue(usuario);

                        Intent atividades = new Intent(CadastroUsuariosActivityteste.this, AtividadesActivity.class);
                        startActivity(atividades);

                    }else{
                        String mensagem = "Falha ao cadastrar";
                        Toast.makeText(CadastroUsuariosActivityteste.this, mensagem, Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
     }
}
