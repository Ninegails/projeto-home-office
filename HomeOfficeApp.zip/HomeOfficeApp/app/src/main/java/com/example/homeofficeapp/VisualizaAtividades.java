package com.example.homeofficeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class VisualizaAtividades extends AppCompatActivity {

    FirebaseAuth auth;

    RecyclerView recyclerViewAtividades;
    TextView textViewMensagem;
    List<Atividade> listaAtividades = new ArrayList<>();
    AtividadesAdapter atividadesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualiza_atividades);

        auth = FirebaseAuth.getInstance();

        recyclerViewAtividades = findViewById(R.id.RecyclerViewAtividades);
        textViewMensagem = findViewById(R.id.textViewMensagem);
        atividadesAdapter = new AtividadesAdapter(listaAtividades, getApplicationContext());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerViewAtividades.setLayoutManager(layoutManager);
        recyclerViewAtividades.setHasFixedSize(true);
        recyclerViewAtividades.setAdapter(atividadesAdapter);
        recuperaAtividadesSalvas();
    }

    private void recuperaAtividadesSalvas(){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("AtividadeFinalizada");

        Query pesquisaAtividades = reference.orderByChild("idFuncionario").equalTo(auth.getCurrentUser().getUid());

        pesquisaAtividades.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.getChildrenCount() > 0){
                    textViewMensagem.setVisibility(View.GONE);
                    recyclerViewAtividades.setVisibility(View.VISIBLE);
                }else{
                    textViewMensagem.setVisibility(View.VISIBLE);
                    recyclerViewAtividades.setVisibility(View.GONE);
                }

                for(DataSnapshot ds: dataSnapshot.getChildren()){
                    Atividade atividade = ds.getValue(Atividade.class);
                    listaAtividades.add(atividade);
                }

                atividadesAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){

        switch (item.getItemId()){
            case R.id.menuSair:auth.signOut();
            startActivity(new Intent(VisualizaAtividades.this, MainActivity.class));
            break;
        }

        return super.onOptionsItemSelected(item);
    }
}
